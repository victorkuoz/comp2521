// Reads a wall data file

#ifndef WALL_READER_H
#define WALL_READER_H

Wall readWall(char *wallFilename);

#endif

